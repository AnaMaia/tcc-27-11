<?php  @ $_SESSION['tipo_user'];

require_once __DIR__."/indexperfil.php" ?>
    <div id="page-wrapper">
        <!-- Page Content -->

        <div id="page-inner" class="container">

            <a href="cadastroprodutos.php" class="ui button" >Cadastrar Novos Produtos <i class="glyphicon glyphicon-plus-sign" style=" margin-left: 5px"></i> </a>
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>

<?php require_once __DIR__. "/rodape.php"; ?>