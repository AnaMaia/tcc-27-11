<?php
define('host', 'localhost');
define('user', 'root');
define('pass', '');
define('db', 'leaneth');